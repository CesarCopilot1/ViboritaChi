package com.example.snakecesar

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View

class MainActivity : AppCompatActivity() {

    private lateinit var gameView: SnakeGameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gameView = findViewById(R.id.game_view)

        // Configurar las áreas de control para cambiar la dirección de la serpiente
        findViewById<View>(R.id.area_up).setOnClickListener {
            gameView.setDirection(SnakeGameView.Direction.UP)
        }

        findViewById<View>(R.id.area_down).setOnClickListener {
            gameView.setDirection(SnakeGameView.Direction.DOWN)
        }

        findViewById<View>(R.id.area_left).setOnClickListener {
            gameView.setDirection(SnakeGameView.Direction.LEFT)
        }

        findViewById<View>(R.id.area_right).setOnClickListener {
            gameView.setDirection(SnakeGameView.Direction.RIGHT)
        }
    }
}
