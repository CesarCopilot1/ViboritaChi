package com.example.snakecesar
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.view.GestureDetectorCompat

class SnakeGameView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val snakeBody = mutableListOf<Pair<Int, Int>>()
    private var direction = Direction.RIGHT
    private val handler = android.os.Handler()
    private var foodPosition = Pair(5, 5)
    private var gameRunning = true

    // Detector de gestos
    private val gestureDetector = GestureDetectorCompat(context, SwipeGestureListener())
    // Bucle del juego
    private val gameLoop = object : Runnable {
        override fun run() {
            if (gameRunning) {
                moveSnake()
                checkCollision()
                invalidate() // Redibuja el juego
                handler.postDelayed(this, 500)
            }
        }
    }

    init {
        snakeBody.add(Pair(10, 10))
        handler.postDelayed(gameLoop, 500)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Dibujar el fondo
        canvas.drawColor(Color.WHITE)

        // Dibujar la serpiente
        val paint = Paint()
        paint.color = Color.GREEN
        snakeBody.forEach { part ->
            canvas.drawRect(
                (part.first * 40).toFloat(),
                (part.second * 40).toFloat(),
                (part.first * 40 + 40).toFloat(),
                (part.second * 40 + 40).toFloat(),
                paint
            )
        }

        // Dibujar la comida
        paint.color = Color.RED
        canvas.drawRect(
            (foodPosition.first * 40).toFloat(),
            (foodPosition.second * 40).toFloat(),
            (foodPosition.first * 40 + 40).toFloat(),
            (foodPosition.second * 40 + 40).toFloat(),
            paint
        )
    }


    private fun moveSnake() {
        val head = snakeBody.first()
        val newHead = when (direction) {
            Direction.UP -> Pair(head.first, head.second - 1)
            Direction.DOWN -> Pair(head.first, head.second + 1)
            Direction.LEFT -> Pair(head.first - 1, head.second)
            Direction.RIGHT -> Pair(head.first + 1, head.second)
        }

        snakeBody.add(0, newHead)
        if (newHead == foodPosition) {
            // Si la serpiente come la comida
            generateNewFood()
        } else {
            snakeBody.removeAt(snakeBody.size - 1) // Mover la serpiente
        }
    }

    private fun checkCollision() {
        val head = snakeBody.first()
        if (head.first < 0 || head.second < 0 || head.first >= 27 || head.second >= 16) {
           // gameRunning = false // Fuera de límites
            resetGame();
        }

        if (snakeBody.drop(1).contains(head)) {
            //gameRunning = false // Colisión consigo misma
            resetGame();
        }
    }

    private fun generateNewFood() {
        foodPosition = Pair((0..27).random(), (0..16).random())
    }

    // Método para cambiar la dirección
    fun setDirection(newDirection: Direction) {
        if ((direction == Direction.UP && newDirection != Direction.DOWN) ||
            (direction == Direction.DOWN && newDirection != Direction.UP) ||
            (direction == Direction.LEFT && newDirection != Direction.RIGHT) ||
            (direction == Direction.RIGHT && newDirection != Direction.LEFT)
        ) {
            direction = newDirection
        }
    }

    // Enum de direcciones
    enum class Direction {
        UP, DOWN, LEFT, RIGHT
    }

    // Interceptar los eventos táctiles y pasarlos al GestureDetector
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        return event?.let { gestureDetector.onTouchEvent(it) } ?: false
    }

    // Clase para manejar los gestos de deslizamiento
    private inner class SwipeGestureListener : GestureDetector.SimpleOnGestureListener() {
        private val SWIPE_THRESHOLD = 100
        private val SWIPE_VELOCITY_THRESHOLD = 100

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            try {
                val diffX = e2.x - e1!!.x
                val diffY = e2.y - e1.y
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    // Deslizamiento horizontal
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            setDirection(Direction.RIGHT) // Deslizó hacia la derecha
                        } else {
                            setDirection(Direction.LEFT) // Deslizó hacia la izquierda
                        }
                    }
                } else {
                    // Deslizamiento vertical
                    if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffY > 0) {
                            setDirection(Direction.DOWN) // Deslizó hacia abajo
                        } else {
                            setDirection(Direction.UP) // Deslizó hacia arriba
                        }
                    }
                }
                return true
            } catch (exception: Exception) {
                exception.printStackTrace()
            }
            return false
        }
    }
    fun resetGame() {
        snakeBody.clear()
        snakeBody.add(Pair(10, 10)) // Restablece la serpiente en su posición inicial
        direction = Direction.RIGHT // Restablece la dirección
        generateNewFood() // Genera nueva comida
        gameRunning = true // El juego está en ejecución nuevamente
        invalidate() // Redibuja el juego
    }

}
